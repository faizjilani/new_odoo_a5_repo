# -*- coding: utf-8 -*-

from . import res_partner
from . import tuba_products
from . import tuba_sale_order
from . import cutomer_receiving
from . import supplier_payment
from . import tuba_purchase_order
from . import tuba_sale_damage


