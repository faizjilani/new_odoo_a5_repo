# -*- coding: utf-8 -*-

from . import tuba_customer_report_wizard
from . import tuba_supplier_report_wizard
from . import tuba_inventory_report_wizard


